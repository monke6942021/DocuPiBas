# -*- coding:utf-8 _*-
""" 
LIB-SSE CODE
@author: Jeza Chen
@license: GPL-3.0 License 
@file: constants.py 
@time: 2022/03/09
@contact: jeza@vip.qq.com
@software: PyCharm 
@description: 
"""

LENGTH_UNLIMITED = -1
LENGTH_NOT_GIVEN = 0
